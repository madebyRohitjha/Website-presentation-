<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <link href="css/styles.css" rel="stylesheet">
    <title>Images and Files</title>
  </head>
  </body>
  <div class="page">
    <a href="index.php">PHP &amp; MySQL</a>
    <h2>Images and Files</h2>
    <table>
      <tr><th>Lab</th><th>Title</th><th>Filename</th></tr>
      <tr><td>1</td><td class="title">Upload File</td><td><a class="link" href="upload-file.php">upload-file.php</a></td></tr>
      <tr><td>2</td><td class="title">Move Temporary File</td><td><a class="link" href="move-file.php">move-file.php</a></td></tr>
      <tr><td>3</td><td class="title">Validate File Upload</td><td><a class="link" href="validate-file.php">validate-file.php</a></td></tr>
      <tr><td>4</td><td class="title">Resize an Image Using GD</td><td><a class="link" href="resize-gd.php">resize-gd.php</a></td></tr>
      <tr><td>5</td><td class="title">Crop and Resize an Image Using GD</td><td><a class="link" href="crop-and-resize-gd.php">crop-and-resize-gd.php</a></td></tr>
      <tr><td>6</td><td class="title">Resize an Image Using ImageMagick</td><td><a class="link" href="resize-im.php">resize-im.php</a></td></tr>
      <tr><td>7</td><td class="title">Crop Image Using ImageMagick</td><td><a class="link" href="crop-im.php">crop-im.php</a></td></tr>
    </table>
    <div>
  </body>
</html>



